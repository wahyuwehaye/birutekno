package com.dicoding.kotlinacademy.model

data class TeamResponse(
        val teams: List<Team>)